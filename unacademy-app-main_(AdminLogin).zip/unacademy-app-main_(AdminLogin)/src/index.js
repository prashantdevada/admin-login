import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';

<<<<<<< HEAD


=======
>>>>>>> 0530117ee37ea8760e5e49554fa7de702d58a2e4
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
   <title>learnerreport</title>
  </React.StrictMode>
<<<<<<< HEAD
);
=======
);
>>>>>>> 0530117ee37ea8760e5e49554fa7de702d58a2e4
